﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.ComponentModel.DataAnnotations;

namespace AbacoCRUD.Shared
{
    public class ObjetivosSector
    {
        public int IdObjetivo { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]
        public int IdEsquema { get; set; }  

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]
        public int IdKpi { get; set; }  

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]
        public int IdCargo { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        
        public string SubGrupoSector { get; set; } = null!;

        [Required(ErrorMessage = "El campo {0} es requerido")]
        public DateTime FechaInicio { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        public DateTime FechaFin { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, double.MaxValue, ErrorMessage = "El valor debe ser mayor que 0.")]
        public decimal Peso { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, double.MaxValue, ErrorMessage = "El valor debe ser mayor que 0.")]
        public decimal Cmto0 { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, double.MaxValue, ErrorMessage = "El valor debe ser mayor que 0.")]
        public decimal Cmto60 { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, double.MaxValue, ErrorMessage = "El valor debe ser mayor que 0.")]
        public decimal Cmto100 { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, double.MaxValue, ErrorMessage = "El valor debe ser mayor que 0.")]
        public decimal Cmto150 { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]
        public int IdTipoKpi { get; set; }


        public EsquemaDTO esquema { get; set; }

        public AbacoKpisDTO AbacoKpis { get; set; }

        public TipoKpiDTO tipoKpiDTO { get; set; }


    }
}
