﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbacoCRUD.Shared
{
    public class Response<T>
    {
        public bool EsCorrecto { get; set; }
        public T? valor {  get; set; }

        public string? Mensaje { get; set; }
    }
}
