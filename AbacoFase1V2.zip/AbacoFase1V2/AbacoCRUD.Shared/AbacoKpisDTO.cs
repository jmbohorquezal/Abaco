﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.ComponentModel.DataAnnotations;

namespace AbacoCRUD.Shared
{
    public class AbacoKpisDTO
    {
        public int IdAbacoKpi { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]

        public int IdKpi { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]

        public string Kpi { get; set; } = null!;

        public string Calculo { get; set; } = null!;

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]

        public int FormatoValor { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]

        public int Configuracion { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        public string Descripcion { get; set; } = null!;

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]
        public int Estado { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        [Range(1, int.MaxValue)]
        public int IdTipoKpi { get; set; }

        public TipoKpiDTO TipoKpi { get; set; } 
    }
}
