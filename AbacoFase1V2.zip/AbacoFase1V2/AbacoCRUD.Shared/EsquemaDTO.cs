﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.ComponentModel.DataAnnotations;

namespace AbacoCRUD.Shared
{
    public class EsquemaDTO
    {
        public int IdEsquema { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido")]
        
        public string Esquema1 { get; set; } = null!;

        [Required(ErrorMessage = "El campo {0} es requerido")]
        public string Legajos { get; set; } = null!;
    }
}
