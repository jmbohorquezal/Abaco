﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using abacoCRUDServer.Models;
using AbacoCRUD.Shared;
using Microsoft.EntityFrameworkCore;

namespace abacoCRUDServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AbacoKpiController : ControllerBase
    {
        private readonly PAbacoV2Context _context;

        public AbacoKpiController(PAbacoV2Context context)
        {
            _context = context;
        }

        [HttpGet]

        [Route("Lista_Objetivos")]
        public async Task<IActionResult> Lista()
        {
            var responseApi = new Response<List<AbacoKpisDTO>>();
            var ListaAbacoKpisDTO = new List<AbacoKpisDTO>();

            try
            {
                foreach (var item in await _context.AbacoKpis.ToListAsync())
                {
                    ListaAbacoKpisDTO.Add(new AbacoKpisDTO
                    {
                        IdKpi = item.IdKpi,
                        Kpi = item.Kpi,
                        Calculo = item.Calculo,
                        FormatoValor = item.FormatoValor,
                        Configuracion = item.Configuracion,
                        Descripcion = item.Descripcion,
                        Estado = item.Estado,
                        IdTipoKpi = item.IdTipoKpi,
                    });
                }

                responseApi.EsCorrecto = true;
                responseApi.valor = ListaAbacoKpisDTO;            
            }catch (Exception ex)
            {
                responseApi.EsCorrecto = false;
                responseApi.Mensaje = ex.Message;
            }
            
            return Ok(responseApi);

        }

    }
}
