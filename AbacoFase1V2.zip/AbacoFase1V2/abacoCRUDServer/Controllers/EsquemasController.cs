﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using abacoCRUDServer.Models;
using AbacoCRUD.Shared;
using Microsoft.EntityFrameworkCore;

namespace abacoCRUDServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EsquemasController : ControllerBase
    {
        private readonly PAbacoV2Context _context;

        public EsquemasController(PAbacoV2Context context)
        {
            _context = context;
        }

        [HttpGet]

        [Route("Lista_Objetivos")]
        public async Task<IActionResult> Lista()
        {
            var responseApi = new Response<List<EsquemaDTO>>();
            var ListaEsquemaDTO = new List<EsquemaDTO>();

            try
            {
                foreach (var item in await _context.Esquemas.ToListAsync())/// revisar en donde itera la navegacion
                {
                    ListaEsquemaDTO.Add(new EsquemaDTO
                    {
                        IdEsquema = item.IdEsquema,
                        Esquema1 = item.Esquema1,
                        Legajos = item.Legajos,


                    });
                }

                responseApi.EsCorrecto = true;
                responseApi.valor = ListaEsquemaDTO;
            }
            catch (Exception ex)
            {
                responseApi.EsCorrecto = false;
                responseApi.Mensaje = ex.Message;
            }

            return Ok(responseApi);

        }



        [HttpGet]

        [Route("Buscar/{id}")]
        public async Task<IActionResult> Buscar(int id)
        {
            var responseApi = new Response<EsquemaDTO>();
            var EsquemaDTO = new EsquemaDTO();

            try
            {
                var dbEsquema = await _context.Esquemas.FirstOrDefaultAsync(x=> x.IdEsquema == id);

                if (dbEsquema != null)
                {
                    EsquemaDTO.IdEsquema = dbEsquema.IdEsquema;
                    EsquemaDTO.Esquema1 = dbEsquema.Esquema1;
                    EsquemaDTO.Legajos = dbEsquema.Legajos;


                    responseApi.EsCorrecto = true;
                    responseApi.valor = EsquemaDTO;
                }
                else
                {
                    responseApi.EsCorrecto = false;
                    responseApi.Mensaje = "No Encontrado";
                }

    

            }
            catch (Exception ex)
            {
                responseApi.EsCorrecto = false;
                responseApi.Mensaje = ex.Message;
            }

            return Ok(responseApi);

        }


        [HttpPost]

        [Route("Guardar")]
        public async Task<IActionResult> Guardar(EsquemaDTO esquema)
        {
            var responseApi = new Response<int>();
        

            try
            {
                var dbEsquema = new Esquema
                {
                    Esquema1 = esquema.Esquema1,
                    Legajos = esquema.Legajos,  
                    
                };

                _context.Esquemas.Add(dbEsquema);
                await _context.SaveChangesAsync();

                if (dbEsquema.IdEsquema != 0)
                {
                    responseApi.EsCorrecto = true;
                    responseApi.valor = dbEsquema.IdEsquema;
                }else
                {
                    responseApi.EsCorrecto = false;
                    responseApi.Mensaje = "No guardado";

                }
            
                               

            }
            catch (Exception ex)
            {
                responseApi.EsCorrecto = false;
                responseApi.Mensaje = ex.Message;
            }

            return Ok(responseApi);

        }



        [HttpPut]

        [Route("Editar/{id}")]
        public async Task<IActionResult> Editar(EsquemaDTO esquema, int id)
        {
            var responseApi = new Response<int>();


            try
            {
                var dbEsquema = await _context.Esquemas.FirstOrDefaultAsync(e => e.IdEsquema == id);

              

                if (dbEsquema != null)
                {
                    dbEsquema.Esquema1 = esquema.Esquema1;
                    dbEsquema.Legajos = esquema.Legajos;


                    _context.Esquemas.Update(dbEsquema);
                    await _context.SaveChangesAsync();


                    responseApi.EsCorrecto = true;
                    responseApi.valor = dbEsquema.IdEsquema;


                }
                else
                {
                    responseApi.EsCorrecto = false;
                    responseApi.Mensaje = "No Se encuentra el esquema";

                }



            }
            catch (Exception ex)
            {
                responseApi.EsCorrecto = false;
                responseApi.Mensaje = ex.Message;
            }

            return Ok(responseApi);

        }

        [HttpDelete]

        [Route("Eliminar/{id}")]
        public async Task<IActionResult> Eliminar( int id)
        {
            var responseApi = new Response<int>();


            try
            {
                var dbEsquema = await _context.Esquemas.FirstOrDefaultAsync(e => e.IdEsquema == id);



                if (dbEsquema != null)
                {
                 


                    _context.Esquemas.Remove(dbEsquema);
                    await _context.SaveChangesAsync();


               


                }
                else
                {
                    responseApi.EsCorrecto = false;
                    responseApi.Mensaje = "No Se encuentra el esquema";

                }



            }
            catch (Exception ex)
            {
                responseApi.EsCorrecto = false;
                responseApi.Mensaje = ex.Message;
            }

            return Ok(responseApi);

        }
    }
}
