﻿using System;
using System.Collections.Generic;

namespace abacoCRUDServer.Models;

public partial class AbacoKpi
{
    public int IdAbacoKpi { get; set; }

    public int IdKpi { get; set; }

    public string Kpi { get; set; } = null!;

    public string Calculo { get; set; } = null!;

    public int FormatoValor { get; set; }

    public int Configuracion { get; set; }

    public string Descripcion { get; set; } = null!;

    public int Estado { get; set; }

    public int IdTipoKpi { get; set; }
}
