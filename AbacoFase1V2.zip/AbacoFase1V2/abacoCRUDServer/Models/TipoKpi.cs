﻿using System;
using System.Collections.Generic;

namespace abacoCRUDServer.Models;

public partial class TipoKpi
{
    public int IdTipoKpi { get; set; }

    public string TipoKpi1 { get; set; } = null!;
}
