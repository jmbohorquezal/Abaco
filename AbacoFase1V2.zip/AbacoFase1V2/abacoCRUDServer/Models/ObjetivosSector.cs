﻿using System;
using System.Collections.Generic;

namespace abacoCRUDServer.Models;

public partial class ObjetivosSector
{
    public int IdObjetivo { get; set; }

    public int IdEsquema { get; set; }

    public int IdKpi { get; set; }

    public int IdCargo { get; set; }

    public string SubGrupoSector { get; set; } = null!;

    public DateTime FechaInicio { get; set; }

    public DateTime FechaFin { get; set; }

    public decimal Peso { get; set; }

    public decimal Cmto0 { get; set; }

    public decimal Cmto60 { get; set; }

    public decimal Cmto100 { get; set; }

    public decimal Cmto150 { get; set; }

    public int IdTipoKpi { get; set; }
}
