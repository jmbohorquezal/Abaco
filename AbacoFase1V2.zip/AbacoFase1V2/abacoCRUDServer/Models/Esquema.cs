﻿using System;
using System.Collections.Generic;

namespace abacoCRUDServer.Models;

public partial class Esquema
{
    public int IdEsquema { get; set; }

    public string Esquema1 { get; set; } = null!;

    public string Legajos { get; set; } = null!;
}
