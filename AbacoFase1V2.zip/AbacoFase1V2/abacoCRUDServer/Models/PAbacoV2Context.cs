﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace abacoCRUDServer.Models;

public partial class PAbacoV2Context : DbContext
{
    public PAbacoV2Context()
    {
    }

    public PAbacoV2Context(DbContextOptions<PAbacoV2Context> options)
        : base(options)
    {
    }

    public virtual DbSet<AbacoKpi> AbacoKpis { get; set; }

    public virtual DbSet<Esquema> Esquemas { get; set; }

    public virtual DbSet<ObjetivosSector> ObjetivosSectors { get; set; }

    public virtual DbSet<TipoKpi> TipoKpis { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder){ }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AbacoKpi>(entity =>
        {
            entity.HasKey(e => e.IdAbacoKpi).HasName("PK__Abaco_Kp__68A00A59D16911B7");

            entity.ToTable("Abaco_Kpi");

            entity.Property(e => e.IdAbacoKpi).HasColumnName("Id_AbacoKpi");
            entity.Property(e => e.IdTipoKpi).HasColumnName("Id_Tipo_Kpi");
        });

        modelBuilder.Entity<Esquema>(entity =>
        {
            entity.HasKey(e => e.IdEsquema).HasName("PK__Esquemas__AA503D3F60871AD1");

            entity.Property(e => e.IdEsquema).HasColumnName("Id_Esquema");
            entity.Property(e => e.Esquema1)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("Esquema");
        });

        modelBuilder.Entity<ObjetivosSector>(entity =>
        {
            entity.HasKey(e => e.IdObjetivo).HasName("PK__Objetivo__CD1CE8958D9748A5");

            entity.ToTable("ObjetivosSector");

            entity.Property(e => e.IdObjetivo)
                .ValueGeneratedNever()
                .HasColumnName("Id_Objetivo");
            entity.Property(e => e.Cmto0)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("Cmto_0");
            entity.Property(e => e.Cmto100)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("Cmto_100");
            entity.Property(e => e.Cmto150)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("Cmto_150");
            entity.Property(e => e.Cmto60)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("Cmto_60");
            entity.Property(e => e.FechaFin).HasColumnType("datetime");
            entity.Property(e => e.FechaInicio).HasColumnType("datetime");
            entity.Property(e => e.IdCargo).HasColumnName("Id_Cargo");
            entity.Property(e => e.IdEsquema).HasColumnName("Id_Esquema");
            entity.Property(e => e.IdTipoKpi).HasColumnName("Id_Tipo_Kpi");
            entity.Property(e => e.Peso)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("peso");
        });

        modelBuilder.Entity<TipoKpi>(entity =>
        {
            entity.HasKey(e => e.IdTipoKpi).HasName("PK__TipoKpi__5FEFFAC331D963BF");

            entity.ToTable("TipoKpi");

            entity.Property(e => e.IdTipoKpi).HasColumnName("Id_Tipo_Kpi");
            entity.Property(e => e.TipoKpi1)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Tipo_Kpi");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
