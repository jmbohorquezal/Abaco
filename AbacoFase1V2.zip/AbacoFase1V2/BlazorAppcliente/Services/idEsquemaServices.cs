﻿using AbacoCRUD.Shared;

namespace BlazorAppcliente.Services
{
    public interface idEsquemaServices
    {
        Task<List<EsquemaDTO>> Lista();
    }
}
