﻿using AbacoCRUD.Shared;
using System.Net.Http.Json;

using static System.Net.WebRequestMethods;


namespace BlazorAppcliente.Services


{
    public class EsquemaService:idEsquemaServices
    {
        private readonly HttpClient _http;

        public EsquemaService(HttpClient http) 
        { 
            _http = http; 
        }

        public async Task<List<EsquemaDTO>> Lista()
        {
            var result = await _http.GetFromJsonAsync<Response<List<EsquemaDTO>>>("api/Esquemas/Lista_Objetivos");

            if (result!.EsCorrecto)
                return result.valor!;
            else
                throw new Exception(result.Mensaje);
            
        }
    }
}
