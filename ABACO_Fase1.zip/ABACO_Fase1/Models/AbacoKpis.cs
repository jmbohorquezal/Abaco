﻿using System.ComponentModel.DataAnnotations;

namespace ABACO_Fase1.Models
{
    public class AbacoKpis
    {
        [Key]
        public int Id_AbacoKpi { get; set; }
        public int IdKPI { get; set; }
        public string Kpi { get; set; }
        public string Calculo { get; set; }
        public int FormatoValor { get; set; }
        public int Configuracion { get; set; }
        public string Descripcion { get; set; }
        public int Estado { get; set; }
        public int IdTipoKpi { get; set; }
        
    }
}
