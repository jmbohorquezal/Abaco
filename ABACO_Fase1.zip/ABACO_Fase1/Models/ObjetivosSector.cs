﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ABACO_Fase1.Models
{
    public class ObjetivosSector
    {
        [Key]
        public int id_Objetivo {  get; set; }
        public int id_Esquema { get; set; }
        public int id_Sector { get; set; }
        public int id_Kpi { get; set; }
        public int id_Cargo { get; set; }
        public string SubGrupSector { get; set; }
        public DateTime Fecha_Inicio { get; set; } 
        public DateTime Fecha_Fin { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal peso { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal cmto_0 { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal cmto_60 { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal cmto_100 { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal cmto_150 { get; set; }
        public int Id_Tipo { get; set; }



    }
}
