﻿using System.ComponentModel.DataAnnotations;

namespace ABACO_Fase1.Models
{
    public class Esquemas
    {
        [Key]
        public int IdEsquema { get; set; }
        public string Esquema { get; set;}
        public string Legajos { get; set; }


    }
}
