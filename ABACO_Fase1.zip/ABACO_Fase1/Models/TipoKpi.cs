﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace ABACO_Fase1.Models
{
    public class TipoKpi
    {
        [Key]
        public int Id { get; set; }     
        public string Tipo_Kpi { get; set; }
    }
}
