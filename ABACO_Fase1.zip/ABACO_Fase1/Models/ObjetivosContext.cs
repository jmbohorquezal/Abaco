﻿using Microsoft.EntityFrameworkCore;

namespace ABACO_Fase1.Models
{
    public class ObjetivosContext :DbContext
    {
        public ObjetivosContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Esquemas> Esquemas { get; set; }
        public DbSet<AbacoKpis> abacoKpis { get; set; }
        public DbSet<ObjetivosSector> objetivosSectors { get; set; }
        public DbSet<TipoKpi> tipoKpis { get; set; }


        protected override void OnModelCreating (ModelBuilder modelBuilder)
        {
            base.OnModelCreating (modelBuilder);
            modelBuilder.Entity<Esquemas>().HasIndex(c => c.IdEsquema);
            modelBuilder.Entity<ObjetivosSector>().HasIndex(c => c.id_Objetivo);
            modelBuilder.Entity<TipoKpi>().HasIndex(c => c.Id);
        }
        
    }
}
