﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ABACO_Fase1.Migrations
{
    /// <inheritdoc />
    public partial class abaco : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "abacoKpis",
                columns: table => new
                {
                    Id_AbacoKpi = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdKPI = table.Column<int>(type: "int", nullable: false),
                    Kpi = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Calculo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FormatoValor = table.Column<int>(type: "int", nullable: false),
                    Configuracion = table.Column<int>(type: "int", nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Estado = table.Column<int>(type: "int", nullable: false),
                    IdTipoKpi = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_abacoKpis", x => x.Id_AbacoKpi);
                });

            migrationBuilder.CreateTable(
                name: "Esquemas",
                columns: table => new
                {
                    IdEsquema = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Esquema = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Legajos = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Esquemas", x => x.IdEsquema);
                });

            migrationBuilder.CreateTable(
                name: "objetivosSectors",
                columns: table => new
                {
                    id_Objetivo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    id_Esquema = table.Column<int>(type: "int", nullable: false),
                    id_Sector = table.Column<int>(type: "int", nullable: false),
                    id_Kpi = table.Column<int>(type: "int", nullable: false),
                    id_Cargo = table.Column<int>(type: "int", nullable: false),
                    SubGrupSector = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Fecha_Inicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Fecha_Fin = table.Column<DateTime>(type: "datetime2", nullable: false),
                    peso = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    cmto_0 = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    cmto_60 = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    cmto_100 = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    cmto_150 = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    Id_Tipo = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_objetivosSectors", x => x.id_Objetivo);
                });

            migrationBuilder.CreateTable(
                name: "tipoKpis",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Tipo_Kpi = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tipoKpis", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Esquemas_IdEsquema",
                table: "Esquemas",
                column: "IdEsquema");

            migrationBuilder.CreateIndex(
                name: "IX_objetivosSectors_id_Objetivo",
                table: "objetivosSectors",
                column: "id_Objetivo");

            migrationBuilder.CreateIndex(
                name: "IX_tipoKpis_Id",
                table: "tipoKpis",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "abacoKpis");

            migrationBuilder.DropTable(
                name: "Esquemas");

            migrationBuilder.DropTable(
                name: "objetivosSectors");

            migrationBuilder.DropTable(
                name: "tipoKpis");
        }
    }
}
