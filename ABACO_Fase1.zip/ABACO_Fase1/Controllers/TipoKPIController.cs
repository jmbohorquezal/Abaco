﻿using ABACO_Fase1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ABACO_Fase1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TipoKPIController : ControllerBase
    {
        private readonly ObjetivosContext _context;  
        public TipoKPIController(ObjetivosContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("Crear")]

        public async Task<IActionResult> CrearTipoKPI(TipoKpi tipoKpi)
        {
            await _context.tipoKpis.AddAsync(tipoKpi);
            await _context.SaveChangesAsync();

            return Ok();

        }

        [HttpGet]
        [Route("buscar")]
        public async Task<IActionResult> BuscarTipoKPI([FromQuery] int id_KPI)
        {
            var tipoKpis = await _context.tipoKpis
                .Where(e => e.Id == id_KPI)
                .ToListAsync();

            return Ok(tipoKpis);
        }


        private bool TipoKPIExiste(int id)
        {
            return _context.Esquemas.Any(e => e.IdEsquema == id);
        }

        [HttpPut]
        [Route("actualizar/{id}")]
        public async Task<IActionResult> ActualizarTipoKPI(int id, [FromBody] TipoKpi tipoKpi)
        {
            if (id != tipoKpi.Id)
                return BadRequest("El ID del esquema no coincide");

            _context.Entry(tipoKpi).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TipoKPIExiste(id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        [HttpDelete]
        [Route("eliminar/{id}")]
        public async Task<IActionResult> EliminarTipoKPI(int id)
        {
            var tipoKpi = await _context.tipoKpis.FindAsync(id);
            if (tipoKpi == null)
                return NotFound();

            _context.tipoKpis.Remove(tipoKpi);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}   
