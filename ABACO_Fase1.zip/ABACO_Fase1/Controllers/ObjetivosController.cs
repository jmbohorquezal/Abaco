﻿using ABACO_Fase1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ABACO_Fase1.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/Objetivos")]
    [ApiController]
    public class ObjetivosController : ControllerBase
    {
        private readonly ObjetivosContext _context;
        public ObjetivosController(ObjetivosContext context) { 
            _context = context; 
        }

        [HttpPost]
        [Route("Crear")]

        public async Task<IActionResult>CrearObjetivo(ObjetivosSector objetivosSector)
        {
            await _context.objetivosSectors.AddAsync(objetivosSector);
            await _context.SaveChangesAsync();

            return Ok();    

        }

        [HttpGet]
        [Route("buscar")]
        public async Task<IActionResult> BuscarObjetivo([FromQuery] int id_Objetivo)
        {
            var Objetivos = await _context.objetivosSectors
                .Where(e => e.id_Objetivo == id_Objetivo)
                .ToListAsync();

            return Ok(Objetivos);
        }


        private bool ObjetivoExiste(int id)
        {
            return _context.objetivosSectors.Any(e => e.id_Objetivo == id);
        }

        [HttpPut]
        [Route("actualizar/{id}")]
        public async Task<IActionResult> ActualizarEsquema(int id, [FromBody] ObjetivosSector objetivos)
        {
            if (id != objetivos.id_Objetivo)
                return BadRequest("El ID del esquema no coincide");

            _context.Entry(objetivos).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ObjetivoExiste(id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        [HttpDelete]
        [Route("eliminar/{id}")]
        public async Task<IActionResult> EliminarObjetivos(int id)
        {
            var Objetivo = await _context.objetivosSectors.FindAsync(id);
            if (Objetivo == null)
                return NotFound();

            _context.objetivosSectors.Remove(Objetivo);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
