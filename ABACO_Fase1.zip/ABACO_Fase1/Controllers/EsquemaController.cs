﻿using ABACO_Fase1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ABACO_Fase1.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/Esquemas")]
    [ApiController]
    public class EsquemaController : ControllerBase
    {
        private readonly ObjetivosContext _context;
        public EsquemaController(ObjetivosContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("Crear")]

        public async Task<IActionResult> CrearEsquema(Esquemas esquemas)
        {
            await _context.Esquemas.AddAsync(esquemas);
            await _context.SaveChangesAsync();

            return Ok();

        }

        [HttpGet]
        [Route("buscar")]
        public async Task<IActionResult> BuscarEsquema([FromQuery] int id_Esquema)
        {
            var esquemas = await _context.Esquemas
                .Where(e => e.IdEsquema == id_Esquema)
                .ToListAsync();

            return Ok(esquemas);
        }


        private bool EsquemaExiste(int id)
        {
            return _context.Esquemas.Any(e => e.IdEsquema == id);
        }

        [HttpPut]
        [Route("actualizar/{id}")]
        public async Task<IActionResult> ActualizarEsquema(int id, [FromBody] Esquemas esquema)
        {
            if (id != esquema.IdEsquema)
                return BadRequest("El ID del esquema no coincide");

            _context.Entry(esquema).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EsquemaExiste(id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        [HttpDelete]
        [Route("eliminar/{id}")]
        public async Task<IActionResult> EliminarEsquema(int id)
        {
            var esquema = await _context.Esquemas.FindAsync(id);
            if (esquema == null)
                return NotFound();

            _context.Esquemas.Remove(esquema);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
