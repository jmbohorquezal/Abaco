﻿using ABACO_Fase1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ABACO_Fase1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AbacoKPIController : ControllerBase
    {
        private readonly ObjetivosContext _context;

        public AbacoKPIController (ObjetivosContext context)
        {
            _context = context;
        }


        [HttpPost]
        [Route("Crear")]

        public async Task<IActionResult> CrearAbacoKPi(AbacoKpis abacoKpis)
        {
            await _context.abacoKpis.AddAsync(abacoKpis);
            await _context.SaveChangesAsync();

            return Ok();

        }

        [HttpGet]
        [Route("buscar")]
        public async Task<IActionResult> BuscarAbacoKPi([FromQuery] int id_KPI_abaco)
        {
            var AbacoKpis = await _context.abacoKpis
                .Where(e => e.Id_AbacoKpi == id_KPI_abaco)
                .ToListAsync();

            return Ok(AbacoKpis);
        }


        private bool AbacoKPiExiste(int id_KPI_abaco)
        {
            return _context.abacoKpis.Any(e => e.Id_AbacoKpi == id_KPI_abaco);
        }

        [HttpPut]
        [Route("actualizar/{id}")]
        public async Task<IActionResult> ActualizarAbacoKPiI(int id_KPI_abaco, [FromBody] AbacoKpis abacoKpis)
        {
            if (id_KPI_abaco != abacoKpis.Id_AbacoKpi)
                return BadRequest("El ID del esquema no coincide");

            _context.Entry(abacoKpis).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AbacoKPiExiste(id_KPI_abaco))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        [HttpDelete]
        [Route("eliminar/{id}")]
        public async Task<IActionResult> EliminarAbacoKPi(int id)
        {
            var id_abaco = await _context.abacoKpis.FindAsync(id);
            if (id_abaco == null)
                return NotFound();

            _context.abacoKpis.Remove(id_abaco);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
